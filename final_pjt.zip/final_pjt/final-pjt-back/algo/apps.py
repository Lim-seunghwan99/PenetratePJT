from django.apps import AppConfig


class AlgoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'algo'
