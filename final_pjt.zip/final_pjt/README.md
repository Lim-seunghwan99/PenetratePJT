pip install -U scikit-learn
ERD 설명
제공된 SQL 문은 간단한 관계형 데이터베이스를 위한 테이블을 정의합니다. 이를 기반으로 한 ERD (Entity-Relationship Diagram)를 다음과 같이 설명할 수 있습니다:

User 테이블:

필드: id, username, email, age, money, salary, financial_products, is_active, is_staff, is_superuser, first_name, last_name, password, last_login, date_joined.
관계:
Article 테이블과 일대다 관계 (user_id 외래 키를 통해).
Article 테이블:

필드: id, user_id, title, content, created_at, updated_at.
관계:
User 테이블과 다대일 관계 (user_id 외래 키를 통해).
Comment 테이블과 일대다 관계 (Comment 테이블에서 article_id를 통해).
Comment 테이블:

필드: id, article_id, user_id, content, created_at, updated_at.
관계:
Article 테이블과 다대일 관계 (article_id 외래 키를 통해).
User 테이블과 다대일 관계 (user_id 외래 키를 통해).
DepositProduct 테이블:

필드: id, fin_prdt_cd, kor_co_nm, fin_prdt_nm, join_deny, join_member, join_way, spcl_cnd, max_limit.
SavingProduct 테이블:

필드: id, fin_prdt_cd, kor_co_nm, fin_prdt_nm, join_deny, join_member, join_way, spcl_cnd, max_limit.
DepositOptions 테이블:

필드: id, product_id, intr_rate_type, intr_rate_type_nm, intr_rate, intr_rate2, save_trm.
관계:
DepositProduct 테이블과 다대일 관계 (product_id 외래 키를 통해).
SavingOptions 테이블:

필드: id, product_id, intr_rate_type, intr_rate_type_nm, rsrv_type, rsrv_type_nm, save_trm, intr_rate, intr_rate2.
관계:
SavingProduct 테이블과 다대일 관계 (product_id 외래 키를 통해).
ERD 관계:

User는 Article과 일대다 관계를 가집니다 (하나의 사용자가 여러 개의 글을 작성할 수 있음).

Article은 User와 다대일 관계를 가집니다 (여러 글이 하나의 사용자에 의해 작성될 수 있음).

Article은 Comment와 일대다 관계를 가집니다 (하나의 글에는 여러 개의 댓글이 달릴 수 있음).

Comment는 User 및 Article과 다대일 관계를 가집니다.

DepositOptions 및 SavingOptions는 각각 DepositProduct 및 SavingProduct와 다대일 관계를 가집니다.

참고:

ERD 다이어그램에는 엔터티, 관계, 기본 키 및 외래 키를 시각적으로 나타내기 위한 기호가 포함됩니다.
User 테이블의 financial_products와 같은 필드는 직렬화 또는 구조화된 데이터를 포함할 수 있습니다.
이자율에 대한 FLOAT 사용은 정밀도 고려사항이 있을 수 있으며, 재정적 계산을 위해 보통 DECIMAL이 선호됩니다.